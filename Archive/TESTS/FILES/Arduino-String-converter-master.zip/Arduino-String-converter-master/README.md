# Arduino-String-converter
This tool creates easely Arduino IDE compatible Strings from JavaScript, CSS, HTML
(One Hour Quick & Durty Project)

If you use an Arduino or ESP8266 as a Webserver, you have to put all the HTML, CSS, and Javasript stuff in variables. 
This tool will help you.

Take a look at the file "Tool Screenshot.pdf" for a better understanding

The .exe File will only work if you have install the coresponding .Net framework.

Source is made with "visual studio 2015 community"

![alt tag](https://github.com/DIYDave/Arduino-String-converter/blob/master/Tool%20Screenshot.jpg)
